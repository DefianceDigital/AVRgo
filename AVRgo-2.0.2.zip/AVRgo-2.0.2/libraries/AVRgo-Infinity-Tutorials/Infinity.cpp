
#include "Arduino.h"

#include "Infinity.h" 

#include <avr/sleep.h>

#include <avr/power.h>

#include <SD.h> // Import SD Card Library to communicate with MMC

void Infinity::sleep(){
	sleep_enable();
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	digitalWrite(MMC, LOW);
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
	SD.end();
	sleep_cpu();
}

void Infinity::battery_read(){
	pinMode(BL, INPUT);
	analogReference(INTERNAL2V56);
	if ((map(analogRead(BL),714, 900, 0, 100)) <= 0) {
		battery_level = 0;
	} else if ((map(analogRead(BL),714, 900, 0, 100)) >= 100) {
		battery_level = 100;
	} else {
		battery_level = (map(analogRead(BL),714, 900, 0, 100));
	}
	analogReference(DEFAULT);
}

void Infinity::rgb_on(){
	R3 = (255 - rgb_R);
	G3 = (255 - rgb_G);
	B3 = (255 - rgb_B);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::rgb_write(int R2, int G2, int B2){
	R3 = (255 - R2);
	G3 = (255 - G2);
	B3 = (255 - B2);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::mmc_on(){
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	SD.begin(SS);
}

void Infinity::led_rgb(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, HIGH);
	pinMode(RED, OUTPUT);
	pinMode(GREEN, OUTPUT);
	pinMode(BLUE, OUTPUT);
}

void Infinity::led_bt(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, LOW);
}

void Infinity::mmc_off(){
	SD.end();
	pinMode(MMC, INPUT);
	digitalWrite(MMC, LOW);
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
}

void Infinity::bt_on(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
}

void Infinity::bt_off(){
	Serial.end();
	pinMode(BT, INPUT);
	digitalWrite(BT, LOW);
	pinMode(RX, INPUT);
	pinMode(TX, INPUT);
	digitalWrite(RX, LOW);
	digitalWrite(TX, LOW);
}

void Infinity::clear_firmware(){
  SD.remove("FIRMWARE.BIN");
}

void Infinity::rgb_off(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_red(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_orange(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 200);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_yellow(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_green(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_blue(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_purple(){
  analogWrite(RED, 200);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_pink(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 75);
}

void Infinity::rgb_white(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_aqua(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}