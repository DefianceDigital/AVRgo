
#ifndef Infinity_h
                                        
#define Infinity_h

#include "Arduino.h"

class Infinity{
	public:
		void sleep();
		void write(int R2, int G2, int B2);	
		int level;
		void read();
		int R;
		int G;
		int B;             
		void erase();
		void begin();
		void end();
		void red();
		void orange();
		void yellow();
		void green();
		void blue();
		void purple();
		void pink();
		void white();
		void aqua();
	private:
		int R3, G3, B3;
};

#endif