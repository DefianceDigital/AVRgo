
#include "Arduino.h"

#include "Infinity.h" 

#include <avr/sleep.h>

void Infinity::sleep(){
	sleep_enable();
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	digitalWrite(MMC, LOW);
	sleep_cpu();
}

void Infinity::read(){
	pinMode(BL, INPUT);
	analogReference(INTERNAL2V56);
	level = map(analogRead(BL),787, 1023, 0, 100);
	analogReference(DEFAULT);
}

void Infinity::write(int R2, int G2, int B2){
	R3 = (255 - R2);
	G3 = (255 - G2);
	B3 = (255 - B2);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::erase(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::begin(){
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);
}

void Infinity::end(){
  pinMode(RED, INPUT);
  pinMode(GREEN, INPUT);
  pinMode(BLUE, INPUT);
}

void Infinity::red(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::orange(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 200);
  analogWrite(BLUE, 255);
}

void Infinity::yellow(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::green(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::blue(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::purple(){
  analogWrite(RED, 200);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::pink(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 75);
}

void Infinity::white(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

void Infinity::aqua(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}