
#ifndef Infinity_h
                                        
#define Infinity_h

#include "Arduino.h"

class Infinity{
	public:
		void sleep();
		void update_firmware(char* x);
		void clear_firmware();
		void mmc_on();
		void mmc_off();
		void bt_on();
		void bt_off();
		void rgb_write(int R2, int G2, int B2);	
		int blx;
		int battery_level;
		void battery_read();
		int rgb_R;
		int rgb_G;
		int rgb_B;
		int rgb_R2;
		int rgb_G2;
		int rgb_B2;
		void rgb_on();
		void rgb_off();
		void led_rgb();
		void led_bt();
		void rgb_red();
		void rgb_orange();
		void rgb_yellow();
		void rgb_green();
		void rgb_blue();
		void rgb_purple();
		void rgb_pink();
		void rgb_white();
		void rgb_aqua();
	private:
		int R3, G3, B3;
};

#endif