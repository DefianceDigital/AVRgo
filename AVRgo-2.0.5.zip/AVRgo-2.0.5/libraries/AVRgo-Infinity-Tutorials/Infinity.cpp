
#include "Arduino.h"

#include "Infinity.h" 

#include <avr/sleep.h>

#include <avr/power.h>

#include <avr/wdt.h>

#include <SD.h> // Import SD Card Library to communicate with MMC

#include <SPI.h>

File readFile;
File writeFile;

void Infinity::sleep(){
	sleep_enable();
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, LOW);
	SD.end();
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
	ADCSRA = 0; // This is where most of sleep power consumption comes from (Roughly 192uA of sleep current)
	MCUCR = _BV (BODS) | _BV (BODSE);  // turn on brown-out enable select (MCUCR Ammounts to roughly 0.7uA of sleep current)
	MCUCR = _BV (BODS);        // this must be done within 4 clock cycles of above
	sleep_cpu();
}

void Infinity::battery_read(){
	analogReference(INTERNAL2V56);
	battery_level = analogRead(BL); // Very 1st reading will be inaccurate
	delay(10); // So we delay 10ms
	blx = analogRead(BL);// And read again
	battery_level = map( constrain(blx,790,1023),790,1023,0,100); // And finally, reference to 100%
	analogReference(DEFAULT);
}

void Infinity::rgb_on(){
	R3 = (255 - rgb_R);
	G3 = (255 - rgb_G);
	B3 = (255 - rgb_B);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::rgb_write(int R2, int G2, int B2){
	R3 = (255 - R2);
	G3 = (255 - G2);
	B3 = (255 - B2);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::update_firmware(char* x){
	Serial.print("Updating firmware to "); Serial.println(x);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	SD.begin(SS);
	SD.remove("firmware.bin");
	readFile = SD.open(x, FILE_READ); // Max 8 Bytes
	writeFile = SD.open("firmware.bin", FILE_WRITE);
	uint8_t buf[512];
	while (readFile.available()){
		x++;
		readFile.read(buf, sizeof(buf));
		writeFile.write(buf, sizeof(buf));
	}
	readFile.close();
	writeFile.close();
	wdt_enable(WDTO_15MS);
	while(1){}
}

void Infinity::mmc_on(){
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	SD.begin(SS);
}

void Infinity::led_rgb(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, HIGH);
	pinMode(RED, OUTPUT);
	pinMode(GREEN, OUTPUT);
	pinMode(BLUE, OUTPUT);
}

void Infinity::led_bt(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, LOW);
}

void Infinity::mmc_off(){
	SD.end();
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, LOW);
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
}

void Infinity::bt_on(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
}

void Infinity::bt_off(){
	Serial.end();
	pinMode(BT, OUTPUT);
	digitalWrite(BT, LOW);
	pinMode(RX, INPUT);
	pinMode(TX, INPUT);
	digitalWrite(RX, LOW);
	digitalWrite(TX, LOW);
}

void Infinity::clear_firmware(){
  SD.remove("FIRMWARE.BIN");
}

void Infinity::rgb_off(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_red(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_orange(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 200);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_yellow(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_green(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_blue(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_purple(){
  analogWrite(RED, 200);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_pink(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 75);
}

void Infinity::rgb_white(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_aqua(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}