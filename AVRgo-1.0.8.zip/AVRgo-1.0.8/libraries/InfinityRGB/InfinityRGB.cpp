
#include "Arduino.h"

#include "InfinityRGB.h" 

void InfinityRGB::write(int R2, int G2, int B2){
	R3 = (255 - R2);
	G3 = (255 - G2);
	B3 = (255 - B2);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void InfinityRGB::erase(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void InfinityRGB::begin(){
  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);
}

void InfinityRGB::end(){
  pinMode(RED, INPUT);
  pinMode(GREEN, INPUT);
  pinMode(BLUE, INPUT);
}

void InfinityRGB::red(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void InfinityRGB::orange(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 200);
  analogWrite(BLUE, 255);
}

void InfinityRGB::yellow(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void InfinityRGB::green(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void InfinityRGB::blue(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void InfinityRGB::purple(){
  analogWrite(RED, 200);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void InfinityRGB::pink(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 75);
}

void InfinityRGB::white(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

void InfinityRGB::aqua(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}