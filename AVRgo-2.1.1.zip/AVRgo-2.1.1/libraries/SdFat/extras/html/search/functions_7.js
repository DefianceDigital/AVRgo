var searchData=
[
  ['halt',['halt',['../class_sys_call.html#a9b1ef8900e97f572ca561760b4dd4191',1,'SysCall']]],
  ['hex',['hex',['../ios_8h.html#ace2036d970905192360d622140bfe336',1,'ios.h']]]
];
