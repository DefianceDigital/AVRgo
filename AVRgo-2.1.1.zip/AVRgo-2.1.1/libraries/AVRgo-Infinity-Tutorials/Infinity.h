#ifndef Infinity_h
                                        
#define Infinity_h

#include "SPI.h"
#endif

class Infinity{
	public:
		void setup_dashboard();
		void recommended_startup();
		void copy_file(char* file1,char* file2);
		void convert_to_bin(char* file1,char* file2);
		void sleep();
		void deep_sleep();
		void load_firmware(char* file);
		void check_update(String cmd);
		void get_caret();
		void clear_firmware();
		void mmc_on();
		void mmc_off();
		void bt_on();
		void bt_off();
		void rgb_write(int R2, int G2, int B2);	
		int blx;
		int battery_level;
		float battery_voltage;
		void battery_read();
		void software_monitor();
		void software_charger();
		int rgb_R;
		int rgb_G;
		int rgb_B;
		int rgb_R2;
		int rgb_G2;
		int rgb_B2;
		void rgb_on();
		void rgb_off();
		void led_rgb();
		void led_bt();
		void rgb_red();
		void rgb_orange();
		void rgb_yellow();
		void rgb_green();
		void rgb_blue();
		void rgb_purple();
		void rgb_pink();
		void rgb_white();
		void rgb_aqua();
		String cmd;
		String serial_in;
		void reset();
		void set_printFile(String SRF);
		void print_file();
		bool M_string;
		void replace_monitor();
	private:
		int R3, G3, B3;
		
};

extern Infinity infinity;