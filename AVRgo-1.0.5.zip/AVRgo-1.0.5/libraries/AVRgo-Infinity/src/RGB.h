#ifndef _RGB_H_INCLUDED
#define _RGB_H_INCLUDED

#include <Arduino.h>

class RGB {
	public:
		bool set(R = 55, G = 155, B = 255);
	private:
		bool begin(pinMode(RED, OUTPUT), pinMode(GREEN, OUTPUT), pinMode(BLUE;, OUTPUT));
		bool end(pinMode(RED, INPUT), pinMode(GREEN, INPUT), pinMode(BLUE;, INPUT));
	
}

bool RGB::write()
{
	Rw = 255 - R;
	Gw = 255 - G;
	Bw = 255 - B;
	analogWrite(RED, Rw);
	analogWrite(GREEN, Gw);
	analogWrite(BLUE, Bw);
}

bool RGB::on()
{
	Rw = 255 - R;
	Gw = 255 - G;
	Bw = 255 - B;
	analogWrite(RED, Rw);
	analogWrite(GREEN, Gw);
	analogWrite(BLUE, Bw);
}

bool RGB::off()
{
	analogWrite(RED, 255);
	analogWrite(GREEN, 255);
	analogWrite(BLUE, 255);
}

#endif