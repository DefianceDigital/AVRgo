
#include "Arduino.h"

#include "Infinity.h" 

#include <avr/sleep.h>

#include <avr/power.h>

#include <avr/wdt.h>

#include <SPI.h>

#include "SdFat.h"

SdFat sd;
SdFile rFile;
SdFile wFile;
SdFile copy1;
SdFile copy2;
char firmware[69];
char firmware2[69];
int x = 0;
int count = 0;
int count2;
String serial_in;
bool M_string = false;
//int count3 = 0;

void Infinity::replace_monitor(){
	
}

void Infinity::sleep(){
	if(!Serial.available()){
	sleep_enable();
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, LOW);
	SPI.end();
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
	ADCSRA = 0; // This is where most of sleep power consumption comes from (Roughly 192uA of sleep current)
	MCUCR = _BV (BODS) | _BV (BODSE);  // turn on brown-out enable select (MCUCR Ammounts to roughly 0.7uA of sleep current)
	MCUCR = _BV (BODS);        // this must be done within 4 clock cycles of above
	sleep_cpu();
	}
}

void Infinity::deep_sleep(){
	if(!Serial.available()){
	sleep_enable();
	set_sleep_mode(SLEEP_MODE_PWR_DOWN);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, LOW);
	SPI.end();
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
	pinMode(BT, OUTPUT);
	digitalWrite(BT, LOW);
	ADCSRA = 0; // This is where most of sleep power consumption comes from (Roughly 192uA of sleep current)
	MCUCR = _BV (BODS) | _BV (BODSE);  // turn on brown-out enable select (MCUCR Ammounts to roughly 0.7uA of sleep current)
	MCUCR = _BV (BODS);        // this must be done within 4 clock cycles of above
	sleep_cpu();
	}
}

void Infinity::battery_read(){
	analogReference(INTERNAL2V56);
	battery_level = analogRead(BL); // Very 1st reading will be inaccurate
	delay(10); // So we delay 10ms
	blx = analogRead(BL);// And read again
	battery_voltage = ((float(blx))*0.004095); // convert blx to voltage
	battery_level = map( constrain(blx,900,1023),900,1023,0,100); // And finally, reference to 100% (3.15V-4.15V)
	analogReference(DEFAULT);
}

void Infinity::recommended_startup(){
	analogReference(INTERNAL2V56);
	battery_level = analogRead(BL); // Very 1st reading will be inaccurate
	delay(10); // So we delay 10ms
	blx = analogRead(BL);// And read again
	if(blx <= 889){
		sleep_enable();
		set_sleep_mode(SLEEP_MODE_PWR_DOWN);
		digitalWrite(MMC, LOW);
		pinMode(MOSI, INPUT);
		pinMode(MISO, INPUT);
		pinMode(SCK, INPUT);
		pinMode(SS, INPUT);
		digitalWrite(MOSI, LOW);
		digitalWrite(MISO, LOW);
		digitalWrite(SCK, LOW);
		digitalWrite(SS, LOW);
		digitalWrite(BT, LOW);
		ADCSRA = 0; // This is where most of sleep power consumption comes from (Roughly 192uA of sleep current)
		MCUCR = _BV (BODS) | _BV (BODSE);  // turn on brown-out enable select (MCUCR Ammounts to roughly 0.7uA of sleep current)
		MCUCR = _BV (BODS);        // this must be done within 4 clock cycles of above
		//wdt_enable(WDTO_8S);
		sleep_cpu();
	} else {
		digitalWrite(MMC, HIGH);
		sd.begin(SS, SD_SCK_MHZ(8));
		sd.remove("FIRMWARE.BIN");
		SPI.end();
	}
}

void Infinity::software_monitor(){
	analogReference(INTERNAL2V56);
	battery_level = analogRead(BL); // Very 1st reading will be inaccurate
	delay(10); // So we delay 10ms
	blx = analogRead(BL);// And read again
	battery_voltage = ((float(blx))*0.004095); // convert blx to voltage
	if(battery_voltage <= 3.30){
		infinity.deep_sleep();
	}
}

void Infinity::software_charger(){
	analogReference(INTERNAL2V56);
	battery_level = analogRead(BL); // Very 1st reading will be inaccurate
	delay(10); // So we delay 10ms
	blx = analogRead(BL);// And read again
	battery_voltage = ((float(blx))*0.004095); // convert blx to voltage
	pinMode(LED, OUTPUT);
	digitalWrite(LED, HIGH);
	if(battery_voltage >= 3.70){
		infinity.rgb_green();
	} else {
		infinity.rgb_red();
	}
}

void Infinity::rgb_on(){
	R3 = (255 - rgb_R);
	G3 = (255 - rgb_G);
	B3 = (255 - rgb_B);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::rgb_write(int R2, int G2, int B2){
	R3 = (255 - R2);
	G3 = (255 - G2);
	B3 = (255 - B2);
	analogWrite(RED, R3);
	analogWrite(GREEN, G3);
	analogWrite(BLUE, B3);
}

void Infinity::copy_file(char* file1,char* file2){
	//x = 0;
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	if (sd.exists(file1)) {
		Serial.print("Copying "); Serial.print(file1); Serial.print(" to "); Serial.println(file2);
		delay(10);
		sd.remove(file2);
		copy1.open(file1, FILE_READ); // Max 8 Bytes
		copy2.open(file2, FILE_WRITE);
		uint8_t buf[512];
		while (copy1.available()){
			x++;
			copy1.read(buf, sizeof(buf));
			copy2.write(buf, sizeof(buf));
		}
		Serial.println("Copy complete");
		copy1.close();
		copy2.close();
	} else {
		Serial.print(file1); Serial.println(" not found");
	}
}

void Infinity::convert_to_bin(char* file1,char* file2){
	x = 0;
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	if (sd.exists(file1)) {
		Serial.print("Copying "); Serial.print(file1); Serial.print(" to "); Serial.println(file2);
		delay(10);
		sd.remove(file2);
		copy1.open(file1, FILE_READ); // Max 8 Bytes
		copy2.open(file2, FILE_WRITE);
		byte buf[512];
		while (copy1.available()){
			x++;
			copy1.read(buf, sizeof(buf));
			for (int i = 0; i < 512; i++){
				buf[i] = (buf[i], BIN);
			}
			copy2.write(buf, sizeof(buf));
		}
		Serial.println("Copy complete");
		copy1.close();
		copy2.close();
		//sd.remove(file1);
	} else {
		Serial.print(file1); Serial.println(" not found");
	}
}



void Infinity::load_firmware(char* file){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	if (sd.exists(file)) {
		if(M_string == true){
			//Serial.println("*M"+'\n'+"*");
			Serial.print("*M"+String("Loading firmware: ")+String(file)+'\n'+"*");
		} else {
			Serial.print("Loading firmware: "); Serial.println(file);
		}
		delay(10);
		sd.remove("firmware.bin");
		rFile.open(file, FILE_READ); // Max 8 Bytes
		wFile.open("firmware.bin", FILE_WRITE);
		uint8_t buf[512];
		while (rFile.available()){
			x++;
			rFile.read(buf, sizeof(buf));
			wFile.write(buf, sizeof(buf));
			//Serial.print(x); Serial.print(" blocks"); Serial.println(" written");
		}
		//Serial.println("done...");
		rFile.close();
		wFile.close();
		wdt_enable(WDTO_15MS);
		while(1){}
	} else {
		if(M_string == true){
			//Serial.println("*M"+'\n'+"*");
			Serial.println("*M"+String("Sketch not found")+'\n'+"*");
		} else {
			Serial.println("Sketch not found");
		}
	}
}

void Infinity::reset(){
	if(M_string == true){
		//Serial.println("*M"+'\n'+"*");
		Serial.println("*M"+String("Resetting...")+'\n'+"*");
	} else {
		Serial.println("Resetting...");
	}
	wdt_enable(WDTO_15MS);
	while(1){}
}

void Infinity::set_printFile(String SRF){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	Serial.println("Updating readFile..");
	delay(10);
	sd.remove("printFile.dat");
	wFile.open("printFile.dat", FILE_WRITE);
	wFile.print(SRF);
	wFile.close();
}

void Infinity::print_file(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	delay(10);
	//rFile.open("printFile.dat", FILE_READ);
	//String setRead = rFile.readStringUntil('\n');
	//rFile.close();
	rFile.open("PING.dat", FILE_READ);
	while(rFile.available()){
		Serial.write(rFile.read());
	}
	rFile.close();
}

void Infinity::get_caret(){
	if(Serial.available()){
		infinity.bt_on();
		int final_count = 0;
		cmd = Serial.readStringUntil('\n');	
		serial_in = cmd;
		char cmd2[(cmd.length()-2)];
		if (cmd == "^H"){
			infinity.load_firmware("sketches/Dashboard.bin");
		} 
		if ((cmd[0] ==  '^') && (cmd[1] == 'L')){ // "^L" should prefix sketchname
			/*for(int i = 2; i < cmd.length(); i++){
				cmd2[final_count] = cmd[i];
				final_count++;
			}
			infinity.load_firmware(cmd2);*/
			serial_in = cmd.substring(2, cmd.length());
			char bufr[serial_in.length()];
			serial_in.toCharArray(bufr, (serial_in.length()+1));
			infinity.load_firmware(bufr);
		}
		if ((cmd[0] ==  '^') && (cmd[1] == '!')){ 
			infinity.reset();
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 'M')){ // Specific to 'Bluetooth Electronics' App
			Serial.println();
			Serial.println("*.kwl"); // Open modify app
			Serial.println("clear_location(2,1)");
			Serial.println("add_monitor(2,1,8,M,3)"); // Remove terminal print restrictions
			Serial.println("*");
			Serial.println("run()");
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 'm')){ // Specific to 'Bluetooth Electronics' App
			Serial.println();
			Serial.println("*.kwl"); // Open modify app
			Serial.println("clear_location(2,1)");
			Serial.println("add_monitor(2,1,8,,1)"); // Create terminal print restrictions
			Serial.println("*");
			Serial.println("run()");
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 'O')){
			for(int i = 2; i < cmd.length(); i++){
				cmd2[final_count] = cmd[i];
				final_count++;
			}
			pinMode(atoi(cmd2), OUTPUT);
			digitalWrite(atoi(cmd2), HIGH);
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 'o')){
			for(int i = 2; i < cmd.length(); i++){
				cmd2[final_count] = cmd[i];
				final_count++;
			}
			pinMode(atoi(cmd2), OUTPUT);
			digitalWrite(atoi(cmd2), LOW);
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 'S')){ 
			infinity.sleep();
		}
		if ((cmd[0] ==  '^') && (cmd[1] == 's')){ 
			infinity.deep_sleep();
		}
	}
}

void Infinity::check_update(String cmd){
	if (cmd == "^H"){
		digitalWrite(AT, HIGH);
		infinity.load_firmware("sketches/Dashboard.bin");
	} 
	if ((cmd[0] ==  '^') && (cmd[1] == 'L')){ // "^L" should prefix sketchname
		digitalWrite(AT, HIGH);	
		serial_in = cmd.substring(2, cmd.length());
		char bufr[serial_in.length()];
		serial_in.toCharArray(bufr, (serial_in.length()+1));
		infinity.load_firmware(bufr);
	}
}

/*void Infinity::setup_dashboard(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	delay(1000);
	Serial.println("*.kwl");
	Serial.println("clear_panel()");
	Serial.println("set_grid_size(12,8)");
	Serial.println("add_text(5,7,small,R,Battery :,245,240,245,)");
	Serial.println("add_text(0,7,small,R,Brightness :,245,240,245,)");
	Serial.println("add_text(10,1,small,R,LED :,245,240,245,)");
	Serial.println("add_text(10,2,small,R,RESET :,245,240,245,)");
	Serial.println("add_text(10,3,small,R,HOME :,245,240,245,)");
	Serial.println("add_text_box(2,0,8,C,Loading...,245,240,245,H)");
	Serial.println("add_text_box(0,1,2,C,LED,245,240,245,1)");
	Serial.println("add_text_box(10,6,2,C,SLEEP,245,240,245,3)");
	Serial.println("add_text_box(0,6,2,C,COLOR,245,240,245,2)");
	Serial.println("add_button(11,3,14,^,H)");
	Serial.println("add_button(11,2,15,^,!)");
	Serial.println("add_button(11,1,17,B,b)");
	Serial.println("add_button(11,0,6,X,x)");
	Serial.println("add_button(10,0,3,D,d)");
	Serial.println("add_button(1,0,2,U,u)");
	Serial.println("add_button(0,0,9,Q,q)");
	Serial.println("add_switch(10,4,4,P,p,0,1)");
	Serial.println("add_slider(0,4,6,0,10,0,C,C,0)");
	Serial.println("add_slider(1,7,2,0,100,100,A,A,0)");
	Serial.println("add_led(0,2,2,L,0,0,255)");
	Serial.println("add_gauge(6,7,5,0,100,5,V,,,10,5)");
	Serial.println("add_monitor(2,1,8,M,3)");
	Serial.println("add_send_box(2,6,8,,^,)");
	Serial.println("set_panel_notes(,,,)");
	Serial.println("run()");
	Serial.println("*");
	M_string = true;
}*/

void Infinity::setup_dashboard(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	Serial.begin(38400);
	delay(1000);
	Serial.println("*.kwl");
	Serial.println("clear_panel()");
	Serial.println("set_grid_size(12,8)");
	Serial.println("add_text(5,7,small,R,Battery :,245,240,245,)");
	Serial.println("add_text(0,7,small,R,Brightness :,245,240,245,)");
	Serial.println("add_text(10,2,small,R,RESET :,245,240,245,)");
	Serial.println("add_text(10,3,small,R,HOME :,245,240,245,)");
	Serial.println("add_text_box(10,6,2,C,SLEEP,245,240,245,3)");
	Serial.println("add_text_box(0,6,2,C,COLOR,245,240,245,2)");
	Serial.println("add_text(10,1,small,R,SAVE :,245,240,245,)");
	Serial.println("add_text(0,1,small,R,*M ON :,245,240,245,)");
	Serial.println("add_text(0,2,small,R,*M OFF :,245,240,245,)");
	Serial.println("add_text(0,3,small,R,LED/RGB :,245,240,245,)");
	Serial.println("add_text_box(2,0,8,C,Loading...,245,240,245,H)");
	Serial.println("add_button(11,0,6,X,x)");
	Serial.println("add_button(10,0,3,D,d)");
	Serial.println("add_button(0,0,9,Q,q)");
	Serial.println("add_button(1,0,2,U,u)");
	Serial.println("add_button(11,1,16,G,g)");
	Serial.println("add_button(11,2,15,^,!)");
	Serial.println("add_button(11,3,14,^,H)");
	Serial.println("add_button(1,3,17,B,b)");
	Serial.println("add_button(1,1,1,^,M)");
	Serial.println("add_button(1,2,24,^,m)");
	Serial.println("add_switch(10,4,4,P,p,0,1)");
	Serial.println("add_slider(0,4,6,0,10,0,C,C,0)");
	Serial.println("add_slider(1,7,2,0,100,100,A,A,0)");
	Serial.println("add_gauge(6,7,5,0,100,0,V,,,10,5)");
	Serial.println("add_send_box(2,6,8,,,)");
	Serial.println("add_monitor(2,1,8,M,3)");
	Serial.println("set_panel_notes(,,,)");
	Serial.println("run()");
	Serial.println("*");
	M_string = true;
}


void Infinity::mmc_on(){
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
}

void Infinity::led_rgb(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, HIGH);
	pinMode(RED, OUTPUT);
	pinMode(GREEN, OUTPUT);
	pinMode(BLUE, OUTPUT);
}

void Infinity::led_bt(){
	pinMode(LED, OUTPUT);
	digitalWrite(LED, LOW);
}

void Infinity::mmc_off(){
	SPI.end();
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, LOW);
	pinMode(MOSI, INPUT);
	pinMode(MISO, INPUT);
	pinMode(SCK, INPUT);
	pinMode(SS, INPUT);
	digitalWrite(MOSI, LOW);
	digitalWrite(MISO, LOW);
	digitalWrite(SCK, LOW);
	digitalWrite(SS, LOW);
}

void Infinity::bt_on(){
	pinMode(BT, OUTPUT);
	digitalWrite(BT, HIGH);
	pinMode(22, OUTPUT);
	digitalWrite(22, HIGH);
	Serial.begin(38400);
}

void Infinity::bt_off(){
	Serial.end();
	pinMode(BT, OUTPUT);
	digitalWrite(BT, LOW);
	pinMode(RX, INPUT);
	pinMode(TX, INPUT);
	digitalWrite(RX, LOW);
	digitalWrite(TX, LOW);
}

void Infinity::clear_firmware(){
	pinMode(MMC, OUTPUT);
	digitalWrite(MMC, HIGH);
	sd.begin(SS, SD_SCK_MHZ(8));
	sd.remove("FIRMWARE.BIN");
}

void Infinity::rgb_off(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_red(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_orange(){
  analogWrite(RED, 50);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_yellow(){
  analogWrite(RED, 100);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_green(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 255);
}

void Infinity::rgb_blue(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_purple(){
  analogWrite(RED, 200);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 0);
}

void Infinity::rgb_pink(){
  analogWrite(RED, 0);
  analogWrite(GREEN, 255);
  analogWrite(BLUE, 75);
}

void Infinity::rgb_white(){
  analogWrite(RED, 0);
  delay(10);
  analogWrite(GREEN, 0);
  delay(10);
  analogWrite(BLUE, 0);
  delay(10);
}

void Infinity::rgb_aqua(){
  analogWrite(RED, 255);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

Infinity infinity = Infinity();