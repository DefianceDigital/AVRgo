
#ifndef Infinity_h
                                        
#define Infinity_h

#include "Arduino.h"

/*#include "FreeStack.h"
#include "MinimumSerial.h"
#include "SysCall.h"
#include "BlockDriver.h"
#include "SdFat.h"
#include "SdFatConfig.h"
#include "sdios.h"*/

class Infinity{
	public:
		//extern SdFile readFile;
		//extern SdFile writeFile;
		void sleep();
		void update_firmware(char* file);
		void serial_update();
		void clear_firmware();
		void mmc_on();
		void mmc_off();
		void bt_on();
		void bt_off();
		void rgb_write(int R2, int G2, int B2);	
		int blx;
		int battery_level;
		void battery_read();
		int rgb_R;
		int rgb_G;
		int rgb_B;
		int rgb_R2;
		int rgb_G2;
		int rgb_B2;
		void rgb_on();
		void rgb_off();
		void led_rgb();
		void led_bt();
		void rgb_red();
		void rgb_orange();
		void rgb_yellow();
		void rgb_green();
		void rgb_blue();
		void rgb_purple();
		void rgb_pink();
		void rgb_white();
		void rgb_aqua();
	private:
		int R3, G3, B3;
		
};

extern Infinity infinity;

//extern SDLib readFile;
//extern SDLib writeFile;

#endif