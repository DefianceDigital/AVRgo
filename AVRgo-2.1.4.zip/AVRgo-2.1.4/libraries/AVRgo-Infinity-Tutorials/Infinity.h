#ifndef Infinity_h
                                        
#define Infinity_h

#include "SPI.h"
#endif

class Infinity{
	public:
	/*static const uint8_t AT;;
static const uint8_t BT;
static const uint8_t MMC;
static const uint8_t RED;
static const uint8_t GREEN;
static const uint8_t BLUE;
static const uint8_t BL;
static const uint8_t RX;
static const uint8_t TX;*/
		void test_print();
		void response_mode(char* rMode);
		char* rMode;
		void xPrint(char xData[]);
		void bPrint(char* xData);
		void ePrint(char* xData);
		void setup_dashboard();
		void recommended_startup();
		void copy_file(char* file1,char* file2);
		void save_file(char* file1,char* data);
		void overwrite_file(char* file1,char* data);
		void setup_clock();
		void enable_clock();
		void send_file(char* file1);
		void receive_file(char* file1);
		void dual_copy(char* file1);
		bool serial_transfer;
		bool clock_enabled;
		bool sleep_enabled;
		void check_sleep();
		void print_file(char* bufr);
		void sleep();
		void deep_sleep();
		void load_firmware(char* file);
		void load_software(char* file, uint32_t offset, uint32_t flashSize);
		void call_alfred();
		void clear_firmware();
		void mmc_on();
		void mmc_off();
		void bt_on();
		void bt_off();
		void rgb_write(int R2, int G2, int B2);	
		int blx;
		int battery_level;
		float battery_voltage;
		void battery_read();
		int rgb_R;
		int rgb_G;
		int rgb_B;
		int rgb_R2;
		int rgb_G2;
		int rgb_B2;
		void rgb_on();
		void rgb_off();
		void led_rgb();
		void led_bt();
		void rgb_red();
		void rgb_orange();
		void rgb_yellow();
		void rgb_green();
		void rgb_blue();
		void rgb_purple();
		void rgb_pink();
		void rgb_white();
		void rgb_aqua();
		String cmd;
		String serial_in;
		String serial_string;
		void reset();
		bool uart0;
		bool uart1;
		bool M_string;
		bool microPython;
	private:
		int R3, G3, B3;
		
};

extern Infinity infinity;