
#ifndef InfinityRGB_h
                                        
#define InfinityRGB_h

#include "Arduino.h"

class InfinityRGB{
	public:
		void write(int R2, int G2, int B2);	
		int R;
		int G;
		int B;
		void on();              
		void off();
		void begin();
		void end();
	private:
		int R3, G3, B3;
};

#endif